import { Injectable } from '@nestjs/common';

import { PrismaService } from '../prisma.service';

import { JwtService } from '@nestjs/jwt';

import * as bcrypt from 'bcrypt';



@Injectable()

export class AuthService {


constructor(

private prisma:PrismaService,

private jwtService:JwtService

){}




async login(
phone:string,
password:string
){


const user =
await this.prisma.user.findUnique({

where:{
phone
}

});



if(!user){

throw new Error('User not found');

}



const valid =
await bcrypt.compare(
password,
user.passwordHash
);



if(!valid){

throw new Error('Wrong password');

}




const payload={

id:user.id,

phone:user.phone,

role:user.role

};



return {


message:'Login successful',


token:
this.jwtService.sign(payload),


user:{

id:user.id,

name:user.name,

phone:user.phone,

role:user.role

}


};



}


}