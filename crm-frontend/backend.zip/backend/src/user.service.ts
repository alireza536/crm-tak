import { Injectable } from '@nestjs/common';
import { PrismaService } from './prisma.service';
import * as bcrypt from 'bcrypt';

@Injectable()
export class UserService {

constructor(
 private prisma: PrismaService
){}




// ======================
// لیست کاربران
// ======================

async findAll(){

return this.prisma.user.findMany({

select:{
id:true,
name:true,
phone:true,
role:true,
createdAt:true
},

orderBy:{
id:'desc'
}

});

}




// ======================
// ساخت کاربر
// ======================

async create(data:any){


const hash =
await bcrypt.hash(
data.password,
10
);



return this.prisma.user.create({

data:{


name:data.name,


phone:data.phone,


address:data.address || "",


personCode:data.personCode || "",


passwordHash:hash,


role:data.role || "SALES"



},


select:{

id:true,
name:true,
phone:true,
role:true

}


});


}



// ======================
// یک کاربر
// ======================

async findOne(id:number){


return this.prisma.user.findUnique({

where:{
id
},

select:{

id:true,
name:true,
phone:true,
role:true

}

});


}



// ======================
// حذف
// ======================

async remove(id:number){


return this.prisma.user.delete({

where:{
id
}

});


}



}