import { Module } from '@nestjs/common';
import { AuthModule } from './auth/auth.module';
import { PrismaModule } from './prisma.module';
import { CustomersModule } from './customers/customers.module';
import { InvoiceModule } from './invoice/invoice.module';
import { UserModule } from './user.module';
import { DashboardModule } from './dashboard/dashboard.module';
@Module({
  imports:[
    PrismaModule,
    AuthModule,
    CustomersModule,
    InvoiceModule,
    UserModule,
    DashboardModule,
  ],
})
export class AppModule {}
