import { PrismaClient } from '@prisma/client';
import * as bcrypt from 'bcrypt';


const prisma = new PrismaClient();


async function main(){


const passwordHash =
await bcrypt.hash(
"123456",
10
);



const admin =
await prisma.user.create({

data:{


name:"Admin",

phone:"09120000000",

personCode:"ADMIN001",

address:"",

passwordHash,

role:"ADMIN"


}

});


console.log(admin);


}



main()
.then(()=>prisma.$disconnect())
.catch(async(e)=>{

console.log(e);

await prisma.$disconnect();

process.exit(1);

});