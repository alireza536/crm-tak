import { Controller, Get, Req, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { DashboardService } from './dashboard.service';

@Controller('dashboard')
export class DashboardController {

constructor(
private dashboardService: DashboardService
){}


@Get('sales')
@UseGuards(JwtAuthGuard)
async salesDashboard(@Req() req){

return this.dashboardService.salesDashboard(
req.user.id
);

}

}