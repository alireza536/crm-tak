import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma.service';


@Injectable()
export class DashboardService {

constructor(
private prisma:PrismaService
){}



async salesDashboard(userId:number){


const customers =
await this.prisma.customer.findMany({

where:{
assignedToId:userId
},

select:{

id:true,
name:true,
phone:true,
status:true,
createdAt:true

}

});



return {

totalCustomers:customers.length,

customers

};


}



}