import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma.service';
import * as bcrypt from 'bcrypt';


@Injectable()
export class SalesService {


constructor(
  private prisma: PrismaService
){}



// =========================
// ساخت فروشنده
// =========================

async create(data:any){


const password =
await bcrypt.hash(
  data.password || "123456",
  10
);



return this.prisma.user.create({

data:{

name:data.name,

phone:data.phone,

address:data.address,

personCode:data.personCode,

passwordHash:password,

role:"SALES"

}

});


}





// =========================
// لیست فروشنده ها
// =========================

async findAll(){


return this.prisma.user.findMany({

where:{

role:"SALES"

},

select:{

id:true,

name:true,

phone:true,

address:true,

role:true,

createdAt:true

},

orderBy:{

id:'desc'

}

});


}






// =========================
// یک فروشنده
// =========================

async findOne(id:number){


return this.prisma.user.findUnique({

where:{

id:id

},

select:{

id:true,

name:true,

phone:true,

address:true,

role:true,


customers:{

orderBy:{

id:'desc'

}

}


}

});


}





// =========================
// حذف فروشنده
// =========================

async remove(id:number){


return this.prisma.user.delete({

where:{

id:id

}

});


}


}