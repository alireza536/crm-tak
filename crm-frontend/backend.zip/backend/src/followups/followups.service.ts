import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { DataSource, EntityManager, Repository } from 'typeorm';
import { Customer } from '../entities/customer.entity';
import { CustomerHistory } from '../entities/customer-history.entity';
import { FollowUp, FollowUpPriority, FollowUpStatus, FollowUpType } from '../entities/follow-up.entity';
import { User } from '../entities/user.entity';

type Actor={id:number;role:string};

@Injectable()
export class FollowupsService {
  constructor(@InjectRepository(FollowUp) private readonly followups:Repository<FollowUp>,private readonly dataSource:DataSource){}

  async create(data:any,actor:Actor){
    this.validate(data,true);
    return this.dataSource.transaction(async manager=>{
      const customer=await manager.getRepository(Customer).findOneBy(actor.role==='ADMIN'?{id:Number(data.customerId)}:{id:Number(data.customerId),salespersonId:actor.id});
      if(!customer)throw new NotFoundException('Customer not found');
      const userId=actor.role==='SALES'?actor.id:Number(data.userId||customer.salespersonId);
      const user=await manager.getRepository(User).findOneBy({id:userId,role:'SALES'});
      if(!user)throw new BadRequestException('Customer must be assigned to a SALES user');
      const status:FollowUpStatus=data.status||'PENDING';
      const item=await manager.getRepository(FollowUp).save({customerId:customer.id,userId:user.id,type:data.type,title:String(data.title).trim(),description:data.description?.trim()||null,status,priority:data.priority||'MEDIUM',dueDate:new Date(data.dueDate),completedAt:status==='DONE'?new Date():null});
      await manager.getRepository(CustomerHistory).save({customerId:customer.id,userId:actor.id,action:'FOLLOW_UP',description:`${item.type}: ${item.title}`});
      return this.one(item.id,actor,manager);
    });
  }

  async all(actor:Actor){await this.markOverdue();return this.followups.createQueryBuilder('followup').leftJoinAndSelect('followup.customer','customer').leftJoinAndSelect('followup.user','user').where(actor.role==='ADMIN'?'1=1':'customer.salespersonId = :userId',{userId:actor.id}).orderBy('followup.dueDate','ASC').getMany()}
  async byCustomer(customerId:number,actor:Actor){await this.requireCustomer(customerId,actor);await this.markOverdue();return this.followups.find({where:{customerId},relations:{customer:true,user:true},order:{dueDate:'DESC'}})}
  async update(id:number,data:any,actor:Actor){this.validate(data,false);const item=await this.accessible(id,actor);if(data.type!==undefined)item.type=data.type;if(data.title!==undefined)item.title=String(data.title).trim();if(data.description!==undefined)item.description=data.description?.trim()||null;if(data.priority!==undefined)item.priority=data.priority;if(data.dueDate!==undefined)item.dueDate=new Date(data.dueDate);if(data.status!==undefined){item.status=data.status;item.completedAt=data.status==='DONE'?new Date():null}return this.followups.save(item)}
  async remove(id:number,actor:Actor){const item=await this.accessible(id,actor);await this.followups.remove(item);return{deleted:true,id}}
  private async accessible(id:number,actor:Actor){const item=await this.followups.createQueryBuilder('followup').leftJoinAndSelect('followup.customer','customer').leftJoinAndSelect('followup.user','user').where('followup.id = :id',{id}).andWhere(actor.role==='ADMIN'?'1=1':'customer.salespersonId = :userId',{userId:actor.id}).getOne();if(!item)throw new NotFoundException('Follow-up not found');return item}
  private async requireCustomer(id:number,actor:Actor){const customer=await this.dataSource.getRepository(Customer).findOneBy(actor.role==='ADMIN'?{id}:{id,salespersonId:actor.id});if(!customer)throw new NotFoundException('Customer not found')}
  private one(id:number,actor:Actor,manager:EntityManager){return manager.getRepository(FollowUp).createQueryBuilder('followup').leftJoinAndSelect('followup.customer','customer').leftJoinAndSelect('followup.user','user').where('followup.id = :id',{id}).andWhere(actor.role==='ADMIN'?'1=1':'customer.salespersonId = :userId',{userId:actor.id}).getOne()}
  private async markOverdue(){await this.followups.createQueryBuilder().update().set({status:'OVERDUE'}).where('status = :status AND dueDate < :now',{status:'PENDING',now:new Date()}).execute()}
  private validate(data:any,create:boolean){const types:FollowUpType[]=['CALL','WHATSAPP','MEETING','QUOTE','PAYMENT','OTHER'],statuses:FollowUpStatus[]=['PENDING','DONE','CANCELLED','OVERDUE'],priorities:FollowUpPriority[]=['LOW','MEDIUM','HIGH'];if((create||data.type!==undefined)&&!types.includes(data.type))throw new BadRequestException('Invalid follow-up type');if((create||data.title!==undefined)&&(!data.title||!String(data.title).trim()))throw new BadRequestException('title is required');if((create||data.dueDate!==undefined)&&Number.isNaN(new Date(data.dueDate).getTime()))throw new BadRequestException('dueDate is invalid');if(data.status!==undefined&&!statuses.includes(data.status))throw new BadRequestException('Invalid follow-up status');if(data.priority!==undefined&&!priorities.includes(data.priority))throw new BadRequestException('Invalid follow-up priority')}
}
