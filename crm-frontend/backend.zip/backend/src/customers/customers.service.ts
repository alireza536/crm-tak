import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma.service';


@Injectable()
export class CustomersService {


  constructor(
    private prisma: PrismaService
  ){}



  // =========================
  // لیست مشتری ها
  // =========================

  async findAll(user:any){


    // ADMIN همه مشتری ها

    if(user.role === 'ADMIN'){


      return this.prisma.customer.findMany({

        include:{
          assignedTo:true
        },

        orderBy:{
          id:'desc'
        }

      });

    }



    // SALES فقط مشتری های خودش

    return this.prisma.customer.findMany({

      where:{
        assignedToId:user.id
      },

      include:{
        assignedTo:true
      },

      orderBy:{
        id:'desc'
      }

    });


  }




  // =========================
  // مشتری های آزاد
  // =========================

  async getFreeCustomers(){


    return this.prisma.customer.findMany({

      where:{
        assignedToId:null
      },

      orderBy:{
        id:'desc'
      }

    });


  }




  // =========================
  // ساخت مشتری
  // =========================

  async create(data:any){


    return this.prisma.customer.create({

      data:{

        name:data.name,

        storeName:data.storeName,

        phone:data.phone,

        address:data.address,

        province:data.province,

        city:data.city

      }

    });


  }




  // =========================
  // یک مشتری
  // =========================

  async findOne(id:number){


    return this.prisma.customer.findUnique({

      where:{
        id:id
      },

      include:{

        assignedTo:true,

        history:{
          orderBy:{
            createdAt:'desc'
          }
        }

      }

    });


  }




  // =========================
  // مشتری های فروشنده
  // =========================

  async getMyCustomers(userId:number){


    return this.prisma.customer.findMany({

      where:{
        assignedToId:userId
      },

      orderBy:{
        id:'desc'
      }

    });


  }





  // =========================
  // Assign مشتری
  // =========================

  async assign(
    customerId:number,
    userId:number
  ){


    const customer =
    await this.prisma.customer.update({

      where:{
        id:customerId
      },

      data:{

        assignedToId:userId

      }

    });



    await this.prisma.customerHistory.create({

      data:{


        customerId:customerId,


        userId:userId,


        action:"ASSIGN",


        description:
        `Customer assigned to user ${userId}`


      }


    });



    return customer;


  }







  // =========================
  // Release مشتری
  // =========================

  async release(
    customerId:number
  ){


    const customer =
    await this.prisma.customer.update({

      where:{
        id:customerId
      },

      data:{

        assignedToId:null

      }

    });



    await this.prisma.customerHistory.create({

      data:{


        customerId:customerId,


        action:"RELEASE",


        description:
        "Customer released"



      }

    });



    return customer;


  }




  // =========================
  // تاریخچه مشتری
  // =========================

  async getHistory(
    customerId:number
  ){


    return this.prisma.customerHistory.findMany({

      where:{
        customerId:customerId
      },


      include:{
        user:true
      },


      orderBy:{
        createdAt:'desc'
      }


    });


  }



}