import { 
  Controller, 
  Get, 
  Post, 
  Body, 
  Param, 
  Patch, 
  Req, 
  UseGuards 
} from '@nestjs/common';

import { CustomersService } from './customers.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';


@Controller('customers')
export class CustomersController {


  constructor(
    private readonly customersService: CustomersService
  ){}



  // لیست مشتری ها
  // ADMIN همه را می بیند
  // SALES فقط مشتری های خودش
  @UseGuards(JwtAuthGuard)
  @Get()
  findAll(
    @Req() req:any
  ){

    return this.customersService.findAll(
      req.user
    );

  }
  // تاریخچه مشتری
@UseGuards(JwtAuthGuard)
@Get(':id/history')
getHistory(
  @Param('id') id:string
){

  return this.customersService.getHistory(
    Number(id)
  );

}



  // مشتری های آزاد
  @UseGuards(JwtAuthGuard)
  @Get('free')
  free(){

    return this.customersService.getFreeCustomers();

  }



  // مشتری های اختصاص داده شده به خود فروشنده
  @UseGuards(JwtAuthGuard)
  @Get('my')
  myCustomers(
    @Req() req:any
  ){

    return this.customersService.getMyCustomers(
      req.user.id
    );

  }



  // ساخت مشتری
  @UseGuards(JwtAuthGuard)
  @Post()
  create(
    @Body() body:any
  ){

    return this.customersService.create(body);

  }



  // گرفتن مشتری با id
  @UseGuards(JwtAuthGuard)
  @Get(':id')
  findOne(
    @Param('id') id:string
  ){

    return this.customersService.findOne(
      Number(id)
    );

  }



  // اختصاص مشتری به فروشنده
  @UseGuards(JwtAuthGuard)
  @Patch(':id/assign')
  assign(
    @Param('id') id:string,
    @Body() body:any
  ){

    return this.customersService.assign(
      Number(id),
      Number(body.userId)
    );

  }



  // آزاد کردن مشتری
  @UseGuards(JwtAuthGuard)
  @Patch(':id/release')
  release(
    @Param('id') id:string
  ){

    return this.customersService.release(
      Number(id)
    );

  }


}